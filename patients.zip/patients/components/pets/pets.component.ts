import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/appointments/services/api.service';

@Component({
  selector: 'app-pets',
  templateUrl: './pets.component.html',
  styleUrls: ['./pets.component.css']
})
export class PetsComponent implements OnInit {

  constructor(private api:ApiService) { }

  patients:any;
  ngOnInit(): void {
    this.api.get_patient().subscribe(data=>{
      this.patients=data;
    })
  }
temp:any;
  set_pat(temp:any){
    this.temp=temp.id;
  }


  delete_pat(){
    this.api.del_patient(this.temp);
  }


  list:boolean=true;
  card:boolean=false;

  lists(){
    this.list =!this.list;
    this.card =!this.card;
  }
  cards(){
    this.card =!this.card;
    this.list =!this.list;
  }
}
