import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/appointments/services/api.service';

@Component({
  selector: 'app-add-pets',
  templateUrl: './add-pets.component.html',
  styleUrls: ['./add-pets.component.css']
})
export class AddPetsComponent implements OnInit {

  constructor(private api:ApiService) { }

  ngOnInit(): void {
  }

  add_patient(value:any){
    this.api.post_patient(value);
    // console.log(value)
    alert('Patients Added');
    window.location.reload();
  }

}
