import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-departments',
  templateUrl: './add-departments.component.html',
  styleUrls: ['./add-departments.component.css']
})
export class AddDepartmentsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
