export class vetDetails{
  //define variable here
}
