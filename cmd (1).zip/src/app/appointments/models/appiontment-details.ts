export class AddAppointment{
  //define variable here
}
