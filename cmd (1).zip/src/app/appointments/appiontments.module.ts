import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AppiontmentsRoutingModule } from './appiontments-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    AppiontmentsRoutingModule,
  
  ]
})
export class AppiontmentsModule { }
