export class petDetails{
  //define variable here
}
